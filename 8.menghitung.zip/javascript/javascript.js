alert("Hitung 2 Bilangan");
var bil1=prompt("Input Bilangan 1=",bil1);
var bil2=prompt("Input bilangan 2=",bil2);

var konfirmasi=confirm("Apakah anda ingin membuka halaman ini?");

if(konfirmasi==true){
    document.write(parseInt(bil1)+parseInt(bil2));
}else{
    document.location.href="http://localhost/javascript/indeks.html";
}