<?php
   echo("Nama: " . $_POST['fname'] . "<br />\n");
   echo("Asal: " . $_POST['fasal'] . "<br />\n");
?>